package com.example.sveta_kurs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SvetaKursApplicationTests {

	@Test
	void contextLoads() {
	}

}
