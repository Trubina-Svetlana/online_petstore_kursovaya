package com.example.Zooshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
//инициализация и запуск приложения
@SpringBootApplication
public class Pet_Store_Application extends SpringBootServletInitializer{
    public static void main(String[] args) {
        SpringApplication.run(Pet_Store_Application.class,args);
    }
}
