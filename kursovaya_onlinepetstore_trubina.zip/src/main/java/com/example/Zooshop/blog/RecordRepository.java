package com.example.Zooshop.blog;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface RecordRepository extends JpaRepository<Record, Long> {
    @Query("select p from Record p where concat(p.id, '',  p.supplier_name, '', p.work_date, '', p.text) LIKE %?1%")
    List<Record> search(String keyword);

    @Query("SELECT p from Record p where p.work_date LIKE %:keyword%")
    List<Record> findByPublishDate(@Param("keyword") String keyword);
    @Query("SELECT p from Record p where p.supplier_name LIKE %:keyword%")
    List<Record> findByAuthor(@Param("keyword") String keyword);
    @Query("SELECT p from Record p where p.text LIKE %:keyword%")
    List<Record> findByText(@Param("keyword") String keyword);
}

