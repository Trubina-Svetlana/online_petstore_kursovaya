package com.example.Zooshop.blog;

import jakarta.persistence.Entity; // аннотация для указания, что класс является сущностью и относится к ORM JPA
import jakarta.persistence.GeneratedValue; // аннотация для работы со столбцами SQL
import jakarta.persistence.GenerationType; // класс, отвечающий за тип данных перечисления
import jakarta.persistence.Id; // аннотация, отвечающая за определение первичного ключа объекта
import org.springframework.stereotype.Component;


@Entity
@Component
public class Record {
    private Long id;
    private String work_date;
    private String text;
    private String supplier_name;

    public Record() {
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }


    public String getWork_date() {
        return work_date;
    }

    public void setWork_date(String work_date) {
        this.work_date = work_date;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getSupplier_name() {
        return supplier_name;
    }

    public void setSupplier_name(String supplier_name) {
        this.supplier_name = supplier_name;
    }

    @Override
    public String toString() {
        return "car [id=" + id + ", work date=" + work_date + ", text=" + text + ", supplier name=" + supplier_name + "]";
    }
}

