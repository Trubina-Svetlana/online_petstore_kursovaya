package com.example.Zooshop.petproducts;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface Pet_ProductRepository extends JpaRepository<Pet_Product, Long>{
    @Query("select p from Pet_Product p where concat(p.id, '', p.name, '', p.supplier_name, '', p.date_arrival, '', p.thematics, '', p.rating) LIKE %?1%")
    List<Pet_Product> search(String keyword);

}
