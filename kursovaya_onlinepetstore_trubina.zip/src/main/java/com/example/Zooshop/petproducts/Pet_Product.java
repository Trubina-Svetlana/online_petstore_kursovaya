package com.example.Zooshop.petproducts;

import jakarta.persistence.Entity; // аннотация для указания, что класс является сущностью и относится к ORM JPA
import jakarta.persistence.GeneratedValue; // аннотация для работы со столбцами SQL
import jakarta.persistence.GenerationType; // класс, отвечающий за тип данных перечисления
import jakarta.persistence.Id; // аннотация, отвечающая за определение первичного ключа объекта
import org.springframework.stereotype.Component;


@Entity
@Component
public class Pet_Product {
    private Long id;
    private String name;
    private String supplier_name;
    private String date_arrival;
    private String thematics;
    private String rating;

    protected Pet_Product() {
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSupplier_name() {
        return supplier_name;
    }

    public void setSupplier_name(String supplier_name) {
        this.supplier_name = supplier_name;
    }

    public String getDate_arrival() {
        return date_arrival;
    }

    public void setDate_arrival(String date_arrival) {
        this.date_arrival = date_arrival;
    }

    public String getThematics() {
        return thematics;
    }

    public void setThematics(String thematics) {
        this.thematics = thematics;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    @Override
    public String toString() {
        return "conference [id=" + id + ", name=" + name + ", supplier name=" + supplier_name + ", date arrival=" + date_arrival + ", thematics=" + thematics + ", rating=" + rating +  "]";
    }
}
